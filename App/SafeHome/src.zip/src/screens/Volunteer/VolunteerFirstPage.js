import React, {Component} from 'react';
import {Platform, StyleSheet, Text, View, Animated, Easing, TouchableOpacity,Image} from 'react-native';
import { Button, Input, Icon } from 'react-native-elements';


class VolunteerFirstPage extends Component{
    static navigationOptions= {
        headerLeft:null,
        headerTitle: (
                <Image
                resizeMode="contain" 
                source={require('../../../assets/img/plaingrey-07.png')}
                style={{height:50,width:50,flex:1}}/>
        ),
      }
    render(){
        return(
            <View>

            </View>
        );
    }
}

export default VolunteerFirstPage;